#include <stdio.h>
#include <stdlib.h> 
#include <string.h>
#include <math.h>
#include "main.h"


// пины строк клавиатуры
uint16_t row_pins[4] = { GPIO_PINS_4, GPIO_PINS_5, GPIO_PINS_6, GPIO_PINS_7 };

// переменные для антидребезга
uint8_t button_state = 0;
uint8_t button_count = 0;
uint8_t last_state = 0;

uint8_t key; // полученное значение кнопки (кнопка не нажата = 0)

char buffer[3]; // буффер для введенного числа
uint8_t buffer_count = 0;

uint8_t hidden_number; // загаданное число

uint8_t count_try = 0; // количество попыток

char str[20]; // строка , которая отправляется на ПК


int main(void)
{	
	keyboard_init();
	set_all_cols_high();
	system_clock_config();
	uart_init();
	SysTick_Config(system_core_clock / 1000);

	hidden_number = random_value() % 100;
	
	while(1) {	}
} 


void keyboard_init(void)
{
	// clock PORT A
	CRM->apb2en_bit.gpioaen = 1;
	// C4
	GPIOA->cfglr_bit.iomc0 = 0x01;
	GPIOA->cfglr_bit.iofc0 = 0x00;
	// C3
	GPIOA->cfglr_bit.iomc1 = 0x01;
	GPIOA->cfglr_bit.iofc1 = 0x00;
	// C2
	GPIOA->cfglr_bit.iomc2 = 0x01;
	GPIOA->cfglr_bit.iofc2 = 0x00;
	// C1
	GPIOA->cfglr_bit.iomc3 = 0x01;
	GPIOA->cfglr_bit.iofc3 = 0x00;
	
	// R1
	GPIOA->cfglr_bit.iomc4 = 0x00;
	GPIOA->cfglr_bit.iofc4 = 0x02;
	GPIOA->odt_bit.odt4 = 1;

	// R2
	GPIOA->cfglr_bit.iomc5 = 0x00;
	GPIOA->cfglr_bit.iofc5 = 0x02;
	GPIOA->odt_bit.odt5 = 1;

	// R3
	GPIOA->cfglr_bit.iomc6 = 0x00;
	GPIOA->cfglr_bit.iofc6 = 0x02;
	GPIOA->odt_bit.odt6 = 1;

	// R4
	GPIOA->cfglr_bit.iomc7 = 0x00;
	GPIOA->cfglr_bit.iofc7 = 0x02;
	GPIOA->odt_bit.odt7 = 1;	
}


void set_all_cols_high(void)
{
	GPIOA->odt |=	GPIO_PINS_0;
	GPIOA->odt |=	GPIO_PINS_1;
	GPIOA->odt |=	GPIO_PINS_2;
	GPIOA->odt |=	GPIO_PINS_3;
}


void set_col_low(uint8_t col)
{
	set_all_cols_high();
	if (col == 1)
		GPIOA->odt &=	~GPIO_PINS_3;
	else if (col == 2)
		GPIOA->odt &=	~GPIO_PINS_2;
	else if (col == 3)
		GPIOA->odt &=	~GPIO_PINS_1;
	else if (col == 4)
		GPIOA->odt &=	~GPIO_PINS_0;
	
	uint16_t t = 10000;
	while (t > 0) { t--; };
}


uint8_t keypad_scan(void)
{
	for (int col = 1; col < 5; col++) {
		set_col_low(col);
		
		for (int row = 0; row < 4; row++) {
			if (!gpio_input_data_bit_read(GPIOA, row_pins[row])) 
				return row * 4 + col;
		}
	}
	return 0;
}


void SysTick_Handler(void)
{
	key = keypad_scan();
	state_change_button();
}


void state_change_button(void)
{
	if (key)
	{
		if (key == last_state)
		{
			if (button_count < 5) // 5 ms
			{
				button_count++;
			}
			else if (button_state == 0)
			{
				switch (key) {
					case   1: { buffer[buffer_count++] = '1'; } break;
					case   2: { buffer[buffer_count++] = '2'; } break;
					case   3: { buffer[buffer_count++] = '3'; } break;
					case   5: { buffer[buffer_count++] = '4'; } break;
					case   6: { buffer[buffer_count++] = '5'; } break;
					case   7: { buffer[buffer_count++] = '6'; } break;
					case   9: { buffer[buffer_count++] = '7'; } break;
					case  10: { buffer[buffer_count++] = '8'; } break;
					case  11: { buffer[buffer_count++] = '9'; } break;
					case  14: { buffer[buffer_count++] = '0'; } break;
					
					case   4: send_value(); break;
					case   8: send_value(); break;
					case  12: send_value(); break;
					case  13: send_value(); break;
					case  15: send_value(); break;
					case  16: send_value(); break;
				}
				button_state = 1;
			}
		}
		last_state = key;
	}
	else 
	{
		if (button_count > 0)
		{
			button_count--;
		}
		else if (button_state == 1)
		{
			button_state = 0;
		}
	}
}


uint32_t random_value (void)
{
	CRM->apb2en_bit.adc1en = 1;
	CRM->cfg_bit.adcdiv_l = 1;
	CRM->cfg_bit.adcdiv_h = 1;
		
	ADC1->ctrl2_bit.itsrven = 1;
	
	ADC1->spt1_bit.cspt16 = 7;
	ADC1->osq1_bit.osn16 = 16;
	
	ADC1->ctrl2_bit.adcen = 1;
	
	
	ADC1->ctrl2_bit.adcalinit = 1;
	while (!(ADC1->ctrl2_bit.adcalinit == 0));
	
	ADC1->ctrl2_bit.adcal = 1;
	while (!(ADC1->ctrl2_bit.adcal == 0));
	
	uint32_t acc = 0;

	for (uint8_t i = 0; i < 32; i++)
	{
		ADC1->ctrl2_bit.ocswtrg = 1;
		ADC1->ctrl2_bit.adcen = 1;
		while (!(ADC1->sts_bit.cce == 1));
		uint16_t sample = ADC1->odt_bit.odt;
		acc = (acc << 1) | (sample & 1);	
	}
	ADC1->ctrl2_bit.adcen = 0;
	
	return acc;
}


void send_value (void)
{
	uint8_t value = atoi(buffer);
	
	sprintf(str, "Enter number: %d\r\n", value);
	uart_send_string(str);
	
	if (value == hidden_number)
	{
		++count_try;
		sprintf(str, "GREAT! Attempt number: %d\r\n", count_try);
		uart_send_string(str);
		count_try = 0;
		hidden_number = random_value() % 100;
	}
	else if (hidden_number > value)
	{
		++count_try;
		uart_send_string("More");
		
	}
	else if (hidden_number < value)
	{
		++count_try;
		uart_send_string("Less");		
	}
	
	buffer_count = 0;
	memset(buffer, 0, sizeof(buffer));
}


void uart_init (void)
{
	// Set USART1
	CRM->apb2en_bit.gpioaen = 1;
	
	// TX
	GPIOA->cfghr_bit.iomc9 = 0x01;
	GPIOA->cfghr_bit.iofc9 = 0x02;
	
	// RX
	GPIOA->cfghr_bit.iomc10 = 0x00;
	GPIOA->cfghr_bit.iofc10 = 0x02;
	GPIOA->odt_bit.odt10 = 1;

	CRM->apb2en_bit.usart1en = 1;
	USART1->ctrl1_bit.ten = 1;
	USART1->baudr_bit.div = 12500; // for 9600 baud
	USART1->ctrl1_bit.uen = 1;
}


void uart_send_string(const char *s) 
{
	while (*s) {
		while (!(USART1->sts_bit.tdbe == 0))
		USART1->dt = *s++; 
	}
}

