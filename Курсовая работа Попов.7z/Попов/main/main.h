#pragma once

#include "at32f403a_407.h"
#include "at32f403a_407_clock.h"


void state_change_button(void); // антидребезг кнопок


void keyboard_init(void); // инициализация клавиатуры
void set_all_cols_high(void); // выставление столбцов в логическую единицу
void set_col_low(uint8_t col); // поочередное установление нуля на стобцах
uint8_t keypad_scan(void); // сканирование клавиатуры

// в функции проверяется введенное число и случайное число, отправляется определенная строка
void send_value (void); 
// инициализация АЦП и получение случайного числа
uint32_t random_value (void);

void uart_init (void); // инициализация юарта
void uart_send_string(const char *s) ; // отправка строки по юарту
